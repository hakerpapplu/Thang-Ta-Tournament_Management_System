<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Thang-Ta Admin</title>
</head>
<body>
    <h1>Welcome to Thang-Ta Admin Panel!</h1>
</body>
</html>
