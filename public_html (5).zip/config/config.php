<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'u845976482_root1');
define('DB_PASS', '#JaiMataDi03');
define('DB_NAME', 'u845976482_thangta');

define('BASE_URL', 'https://mahathangta.in');

